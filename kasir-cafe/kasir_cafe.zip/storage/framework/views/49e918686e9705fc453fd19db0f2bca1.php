<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between mb-4">
    <h1 class="text-xl font-semibold">Buat Stock Opname</h1>
    <a href="<?php echo e(route('admin.stock_opname.index')); ?>" class="px-3 py-2 border rounded text-sm">
        Kembali
    </a>
</div>

<?php if($errors->any()): ?>
    <div class="mb-4 p-3 bg-red-50 border border-red-200 rounded text-sm">
        <div class="font-semibold mb-1">Gagal simpan:</div>
        <ul class="list-disc pl-5">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($e); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(session('status')): ?>
    <div class="mb-4 p-3 bg-green-50 border border-green-200 rounded text-sm">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('admin.stock_opname.store')); ?>">
    <?php echo csrf_field(); ?>

    <div class="grid md:grid-cols-3 gap-4 mb-4">
        <div>
            <label class="block text-sm font-medium mb-1">Tanggal Opname</label>
            <input type="date" name="counted_at"
                   value="<?php echo e(old('counted_at', now()->format('Y-m-d'))); ?>"
                   class="w-full border rounded px-2 py-1 text-sm">
        </div>
        <div class="md:col-span-2">
            <label class="block text-sm font-medium mb-1">Catatan (opsional)</label>
            <textarea name="note" rows="2"
                      class="w-full border rounded px-2 py-1 text-sm"><?php echo e(old('note')); ?></textarea>
        </div>
    </div>

    <div class="bg-white border rounded-lg overflow-hidden">
        <div class="p-3 border-b flex items-center justify-between">
            <div class="font-semibold text-sm">Detail Opname</div>
            <div class="text-xs text-gray-500">
                Stok sistem diambil dari batch aktif (base unit).
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="text-left p-2">Bahan</th>
                        <th class="text-right p-2">Stok Sistem (base)</th>
                        <th class="text-right p-2">Qty Fisik</th>
                        <th class="text-left p-2">Satuan</th>
                        <th class="text-right p-2">Expired (jika +)</th>
                        <th class="text-right p-2">Harga / Satuan Input (opsional)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $oldLines = old('lines', []);
                    ?>

                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            // stok sistem base (sekadar info di form, boleh simple)
                            $systemQtyBase = \App\Models\ItemBatch::query()
                                ->where('item_id', $item->id)
                                ->where('status', 'ACTIVE')
                                ->sum('qty_on_hand_base');

                            $oldLine = $oldLines[$idx] ?? [];
                        ?>
                        <tr class="border-t">
                            <td class="p-2 align-top">
                                <div class="font-medium"><?php echo e($item->name); ?></div>
                                <div class="text-xs text-gray-500">
                                    Base: <?php echo e($item->baseUnit->symbol ?? '-'); ?>

                                </div>

                                
                                <input type="hidden"
                                       name="lines[<?php echo e($idx); ?>][item_id]"
                                       value="<?php echo e($item->id); ?>">
                            </td>

                            <td class="p-2 text-right align-top">
                                <?php echo e(number_format($systemQtyBase, 3, ',', '.')); ?>

                            </td>

                            <td class="p-2 text-right align-top">
                                <input type="number" step="0.001" min="0"
                                       name="lines[<?php echo e($idx); ?>][physical_qty]"
                                       value="<?php echo e($oldLine['physical_qty'] ?? 0); ?>"
                                       class="w-full border rounded px-2 py-1 text-sm text-right">
                            </td>

                            <td class="p-2 align-top">
                                <select name="lines[<?php echo e($idx); ?>][unit_id]"
                                        class="w-full border rounded px-2 py-1 text-sm">
                                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($u->id); ?>"
                                            <?php if(($oldLine['unit_id'] ?? $item->base_unit_id) == $u->id): echo 'selected'; endif; ?>>
                                            <?php echo e($u->symbol); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>

                            <td class="p-2 text-right align-top">
                                <input type="date"
                                       name="lines[<?php echo e($idx); ?>][expired_at]"
                                       value="<?php echo e($oldLine['expired_at'] ?? ''); ?>"
                                       class="border rounded px-2 py-1 text-sm w-full">
                            </td>

                            <td class="p-2 text-right align-top">
                                <input type="number" step="0.01" min="0"
                                       name="lines[<?php echo e($idx); ?>][unit_cost]"
                                       value="<?php echo e($oldLine['unit_cost'] ?? ''); ?>"
                                       class="w-full border rounded px-2 py-1 text-sm text-right"
                                       placeholder="harga per satuan input">
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="border-t">
                            <td colspan="6" class="p-3 text-center text-gray-600">
                                Belum ada item bahan baku.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-4 flex justify-end">
        <button type="submit"
                class="px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">
            Simpan Dokumen
        </button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/chandrairawan/Documents/GitHub/kasir-cafe/N2n-cofe-resto/kasir-cafe/resources/views/admin/stock_opname/create.blade.php ENDPATH**/ ?>