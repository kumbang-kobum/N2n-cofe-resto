<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between mb-4">
  <h1 class="text-xl font-semibold">Penerimaan Stok</h1>
  <a class="px-3 py-2 rounded bg-gray-900 text-white" href="<?php echo e(route('admin.receivings.create')); ?>">+ Terima Stok</a>
</div>

<div class="space-y-3">
  <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white border rounded-lg p-4">
      <div class="flex flex-wrap items-center justify-between gap-2">
        <div>
          <div class="font-semibold">#<?php echo e($p->id); ?> — <?php echo e(\Carbon\Carbon::parse($p->received_at)->format('d M Y H:i')); ?></div>
          <div class="text-sm text-gray-600"><?php echo e($p->supplier_name ?? '-'); ?></div>
        </div>
        <div class="text-sm text-gray-600"><?php echo e($p->lines->count()); ?> item</div>
      </div>

      <div class="mt-3 overflow-x-auto">
        <table class="w-full text-sm">
          <thead class="bg-gray-50">
            <tr>
              <th class="text-left p-2">Bahan</th>
              <th class="text-right p-2">Qty</th>
              <th class="text-right p-2">Cost</th>
              <th class="text-left p-2">Expired</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $p->lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="border-t">
                <td class="p-2"><?php echo e($l->item->name); ?></td>
                <td class="p-2 text-right"><?php echo e($l->qty); ?></td>
                <td class="p-2 text-right"><?php echo e(number_format($l->unit_cost,2,',','.')); ?></td>
                <td class="p-2"><?php echo e(\Carbon\Carbon::parse($l->expired_at)->format('d M Y')); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/chandrairawan/Documents/GitHub/kasir-cafe/N2n-cofe-resto/kasir-cafe/resources/views/admin/receivings/index.blade.php ENDPATH**/ ?>