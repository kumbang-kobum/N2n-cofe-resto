<?php $__env->startSection('content'); ?>
<h1 class="text-xl font-semibold mb-4">Admin Dashboard</h1>

<div class="grid grid-cols-1 md:grid-cols-4 gap-3 mb-6">
  <div class="bg-white border rounded-lg p-4">
    <div class="text-sm text-gray-600">Omzet (<?php echo e($from); ?> s/d <?php echo e($to); ?>)</div>
    <div class="text-lg font-semibold">Rp <?php echo e(number_format($summary['omzet'],0,',','.')); ?></div>
  </div>
  <div class="bg-white border rounded-lg p-4">
    <div class="text-sm text-gray-600">COGS</div>
    <div class="text-lg font-semibold">Rp <?php echo e(number_format($summary['cogs'],0,',','.')); ?></div>
  </div>
  <div class="bg-white border rounded-lg p-4">
    <div class="text-sm text-gray-600">Profit Kotor</div>
    <div class="text-lg font-semibold">Rp <?php echo e(number_format($summary['profit'],0,',','.')); ?></div>
  </div>
  <div class="bg-white border rounded-lg p-4">
    <div class="text-sm text-gray-600">Transaksi</div>
    <div class="text-lg font-semibold"><?php echo e($summary['trx']); ?></div>
  </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
  <div class="bg-white border rounded-lg overflow-hidden">
    <div class="p-4 font-semibold">Stok Menipis</div>
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="bg-gray-50">
          <tr>
            <th class="text-left p-2">Bahan</th>
            <th class="text-right p-2">Stok</th>
            <th class="text-right p-2">Min</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $lowStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="border-t">
              <td class="p-2"><?php echo e($it->name); ?> <span class="text-gray-500">(<?php echo e($it->baseUnit->symbol); ?>)</span></td>
              <td class="p-2 text-right"><?php echo e(number_format($it->stock_base, 3, ',', '.')); ?></td>
              <td class="p-2 text-right"><?php echo e(number_format((float)$it->min_stock, 3, ',', '.')); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr class="border-t"><td class="p-2 text-gray-600" colspan="3">Aman.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="bg-white border rounded-lg overflow-hidden">
    <div class="p-4 font-semibold">Mendekati Expired (≤ 7 hari)</div>
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="bg-gray-50">
          <tr>
            <th class="text-left p-2">Bahan</th>
            <th class="text-right p-2">Qty</th>
            <th class="text-left p-2">Expired</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $expSoon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="border-t">
              <td class="p-2"><?php echo e($b->item->name); ?></td>
              <td class="p-2 text-right"><?php echo e(number_format($b->qty_on_hand_base, 3, ',', '.')); ?></td>
              <td class="p-2"><?php echo e(\Carbon\Carbon::parse($b->expired_at)->format('d M Y')); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr class="border-t"><td class="p-2 text-gray-600" colspan="3">Tidak ada.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/chandrairawan/Documents/GitHub/kasir-cafe/N2n-cofe-resto/kasir-cafe/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>