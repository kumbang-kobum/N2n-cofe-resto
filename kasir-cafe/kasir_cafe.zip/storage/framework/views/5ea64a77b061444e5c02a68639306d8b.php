<?php $__env->startSection('title', 'Edit Stock Opname'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-4 flex items-center justify-between">
        <h1 class="text-xl font-semibold text-gray-800">
            Edit Stock Opname
        </h1>

        <a href="<?php echo e(route('admin.stock_opname.index')); ?>"
           class="inline-flex items-center px-3 py-1.5 text-sm border rounded-md text-gray-700 border-gray-300 hover:bg-gray-50">
            &larr; Kembali
        </a>
    </div>

    <?php if($errors->any()): ?>
        <div class="mb-4 rounded-md bg-red-50 p-3 text-sm text-red-700">
            <div class="font-semibold mb-1">Gagal menyimpan. Periksa kembali input:</div>
            <ul class="list-disc list-inside space-y-0.5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-md shadow-sm border border-gray-200">
        <div class="px-4 py-3 border-b border-gray-200 flex flex-wrap items-center justify-between gap-3">
            <div class="text-sm text-gray-700 space-y-0.5">
                <div>
                    <span class="font-semibold">Kode:</span>
                    <span class="ml-1 font-mono"><?php echo e($opname->code); ?></span>
                </div>
                <div>
                    <span class="font-semibold">Tanggal hitung:</span>
                    <span class="ml-1">
                        <?php echo e(optional($opname->counted_at)->format('d/m/Y')); ?>

                    </span>
                </div>
                <div>
                    <span class="font-semibold">Status:</span>
                    <span class="ml-1">
                        <span class="inline-flex items-center px-2 py-0.5 text-xs rounded-full
                            <?php if($opname->status === 'DRAFT'): ?> bg-yellow-50 text-yellow-800 border border-yellow-200
                            <?php elseif($opname->status === 'POSTED'): ?> bg-green-50 text-green-800 border border-green-200
                            <?php elseif($opname->status === 'CANCELLED'): ?> bg-red-50 text-red-800 border border-red-200
                            <?php else: ?> bg-gray-50 text-gray-700 border border-gray-200 <?php endif; ?>">
                            <?php echo e($opname->status); ?>

                        </span>
                    </span>
                </div>
            </div>

            <div class="text-xs text-gray-500">
                Hanya status <span class="font-semibold">DRAFT</span> yang dapat diedit.
            </div>
        </div>

        <form method="POST" action="<?php echo e(route('admin.stock_opname.update', $opname->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?> 

            <div class="px-4 py-3 border-b border-gray-200">
                <label class="block text-sm font-medium text-gray-700 mb-1" for="note">
                    Catatan
                </label>
                <textarea id="note"
                          name="note"
                          rows="2"
                          class="w-full text-sm border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                          placeholder="Catatan tambahan (opsional)"><?php echo e(old('note', $opname->note)); ?></textarea>
            </div>

            <div class="px-4 py-3 overflow-x-auto">
                <table class="min-w-full text-sm border border-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-3 py-2 border-b border-gray-200 text-left font-semibold text-gray-700">
                                Item
                            </th>
                            <th class="px-3 py-2 border-b border-gray-200 text-right font-semibold text-gray-700">
                                Sistem (base)
                            </th>
                            <th class="px-3 py-2 border-b border-gray-200 text-right font-semibold text-gray-700">
                                Fisik (base)
                            </th>
                            <th class="px-3 py-2 border-b border-gray-200 text-right font-semibold text-gray-700">
                                Selisih (base)
                            </th>
                            <th class="px-3 py-2 border-b border-gray-200 text-center font-semibold text-gray-700">
                                Expired <br><span class="text-xs font-normal text-gray-500">(wajib jika selisih +)</span>
                            </th>
                            <th class="px-3 py-2 border-b border-gray-200 text-right font-semibold text-gray-700">
                                Cost base <br><span class="text-xs font-normal text-gray-500">(wajib jika selisih +)</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $opname->lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $baseUnit = $line->item->baseUnit->symbol ?? '';
                                $diff = $line->diff_qty_base;
                                $diffClass = $diff > 0 ? 'text-green-600' : ($diff < 0 ? 'text-red-600' : 'text-gray-600');
                            ?>
                            <tr class="hover:bg-gray-50 align-top">
                                <td class="px-3 py-2 border-t border-gray-200">
                                    <input type="hidden"
                                           name="lines[<?php echo e($idx); ?>][id]"
                                           value="<?php echo e($line->id); ?>">

                                    <div class="font-semibold text-gray-800">
                                        <?php echo e($line->item->name); ?>

                                    </div>
                                    <div class="text-xs text-gray-500">
                                        <?php echo e($line->item->sku ?? ''); ?>

                                    </div>
                                </td>

                                <td class="px-3 py-2 border-t border-gray-200 text-right text-gray-700">
                                    <?php echo e(number_format($line->system_qty_base, 4)); ?>

                                    <span class="text-xs text-gray-500"><?php echo e($baseUnit); ?></span>
                                </td>

                                <td class="px-3 py-2 border-t border-gray-200 text-right">
                                    <div class="inline-flex items-center gap-1">
                                        <input
                                            type="number"
                                            step="0.0001"
                                            min="0"
                                            name="lines[<?php echo e($idx); ?>][physical_qty_base]"
                                            value="<?php echo e(old('lines.'.$idx.'.physical_qty_base', $line->physical_qty_base)); ?>"
                                            class="w-28 text-right border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                        <span class="text-xs text-gray-500"><?php echo e($baseUnit); ?></span>
                                    </div>
                                    <div class="text-[11px] text-gray-500 mt-0.5">
                                        Ubah jika hasil hitung fisik berubah.
                                    </div>
                                </td>

                                <td class="px-3 py-2 border-t border-gray-200 text-right">
                                    <span class="font-semibold <?php echo e($diffClass); ?>">
                                        <?php echo e(number_format($diff, 4)); ?>

                                        <span class="text-xs"><?php echo e($baseUnit); ?></span>
                                    </span>
                                </td>

                                <td class="px-3 py-2 border-t border-gray-200 text-center">
                                    <input
                                        type="date"
                                        name="lines[<?php echo e($idx); ?>][expired_at]"
                                        value="<?php echo e(old('lines.'.$idx.'.expired_at', optional($line->expired_at)->format('Y-m-d'))); ?>"
                                        class="w-36 text-sm border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                    <div class="text-[11px] text-gray-500 mt-0.5">
                                        Wajib diisi jika selisih plus.
                                    </div>
                                </td>

                                <td class="px-3 py-2 border-t border-gray-200 text-right">
                                    <div class="inline-flex items-center gap-1">
                                        <input
                                            type="number"
                                            step="0.0001"
                                            min="0"
                                            name="lines[<?php echo e($idx); ?>][unit_cost_base]"
                                            value="<?php echo e(old('lines.'.$idx.'.unit_cost_base', $line->unit_cost_base)); ?>"
                                            class="w-28 text-right border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                        <span class="text-xs text-gray-500">/ <?php echo e($baseUnit); ?></span>
                                    </div>
                                    <div class="text-[11px] text-gray-500 mt-0.5">
                                        Dipakai untuk membuat batch baru jika selisih plus.
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if($opname->lines->isEmpty()): ?>
                            <tr>
                                <td colspan="6" class="px-3 py-4 text-center text-sm text-gray-500 border-t border-gray-200">
                                    Tidak ada detail opname.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="px-4 py-3 border-t border-gray-200 flex items-center justify-between">
                <a href="<?php echo e(route('admin.stock_opname.show', $opname->id)); ?>"
                   class="inline-flex items-center px-3 py-1.5 text-sm border rounded-md text-gray-700 border-gray-300 hover:bg-gray-50">
                    Batal
                </a>

                <button type="submit"
                        class="inline-flex items-center px-4 py-2 text-sm font-semibold rounded-md bg-blue-600 text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1">
                    Simpan Perubahan
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/chandrairawan/Documents/GitHub/kasir-cafe/N2n-cofe-resto/kasir-cafe/resources/views/admin/stock_opname/edit.blade.php ENDPATH**/ ?>