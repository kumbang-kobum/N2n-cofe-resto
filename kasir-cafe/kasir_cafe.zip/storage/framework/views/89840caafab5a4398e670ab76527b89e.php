<?php $__env->startSection('content'); ?>
<h1 class="text-xl font-semibold mb-4">Stok</h1>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-4">

  <div class="bg-white border rounded-lg overflow-hidden">
    <div class="p-4 font-semibold">Ringkasan Stok</div>
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="bg-gray-50">
          <tr>
            <th class="text-left p-2">Bahan</th>
            <th class="text-right p-2">Stok (base)</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-t">
              <td class="p-2"><?php echo e($it->name); ?> <span class="text-gray-500">(<?php echo e($it->baseUnit->symbol); ?>)</span></td>
              <td class="p-2 text-right"><?php echo e(number_format($it->stock_base, 3, ',', '.')); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="bg-white border rounded-lg overflow-hidden">
    <div class="p-4 font-semibold">Mendekati Expired (≤ 7 hari)</div>
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="bg-gray-50">
          <tr>
            <th class="text-left p-2">Bahan</th>
            <th class="text-right p-2">Qty</th>
            <th class="text-left p-2">Expired</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $batchesExpSoon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-t">
              <td class="p-2"><?php echo e($b->item->name); ?></td>
              <td class="p-2 text-right"><?php echo e(number_format($b->qty_on_hand_base, 3, ',', '.')); ?></td>
              <td class="p-2"><?php echo e(\Carbon\Carbon::parse($b->expired_at)->format('d M Y')); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php if($batchesExpSoon->isEmpty()): ?>
            <tr class="border-t"><td class="p-2 text-gray-600" colspan="3">Tidak ada.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/chandrairawan/Documents/GitHub/kasir-cafe/N2n-cofe-resto/kasir-cafe/resources/views/admin/stock/index.blade.php ENDPATH**/ ?>