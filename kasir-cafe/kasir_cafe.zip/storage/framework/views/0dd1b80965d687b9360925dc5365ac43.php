<nav class="space-y-1">

  
  <?php if(Route::has('admin.dashboard')): ?>
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="block px-3 py-2 rounded hover:bg-gray-100">
      Dashboard
    </a>
  <?php endif; ?>

  
  <div class="mt-4 text-xs font-semibold text-gray-500 uppercase">Master Data</div>

  <?php if(Route::has('admin.units.index')): ?>
    <a href="<?php echo e(route('admin.units.index')); ?>" class="block px-3 py-2 rounded hover:bg-gray-100">
      Units
    </a>
  <?php endif; ?>

  <?php if(Route::has('admin.items.index')): ?>
    <a href="<?php echo e(route('admin.items.index')); ?>" class="block px-3 py-2 rounded hover:bg-gray-100">
      Items / Bahan
    </a>
  <?php endif; ?>

  <?php if(Route::has('admin.products.index')): ?>
    <a href="<?php echo e(route('admin.products.index')); ?>" class="block px-3 py-2 rounded hover:bg-gray-100">
      Produk / Menu
    </a>
  <?php endif; ?>

  
  <div class="mt-4 text-xs font-semibold text-gray-500 uppercase">Operasional</div>

  <?php if(Route::has('admin.recipes.index')): ?>
    <a href="<?php echo e(route('admin.recipes.index')); ?>" class="block px-3 py-2 rounded hover:bg-gray-100">
      Resep / BOM
    </a>
  <?php endif; ?>

  <?php if(Route::has('admin.receivings.index')): ?>
    <a href="<?php echo e(route('admin.receivings.index')); ?>" class="block px-3 py-2 rounded hover:bg-gray-100">
      Receiving Stok
    </a>
  <?php endif; ?>

  <?php if(Route::has('admin.stock.index')): ?>
    <a href="<?php echo e(route('admin.stock.index')); ?>" class="block px-3 py-2 rounded hover:bg-gray-100">
      Stok Bahan
    </a>
  <?php endif; ?>

  <?php if(Route::has('admin.expired.index')): ?>
    <a href="<?php echo e(route('admin.expired.index')); ?>" class="block px-3 py-2 rounded hover:bg-gray-100 text-red-600">
      Expired Disposal
    </a>
  <?php endif; ?>

  <?php if(Route::has('admin.stock_opname.index')): ?>
  <a class="block px-3 py-2 rounded hover:bg-gray-100" href="<?php echo e(route('admin.stock_opname.index')); ?>">Stock Opname</a>
<?php endif; ?>

  
  <div class="mt-4 text-xs font-semibold text-gray-500 uppercase">Laporan</div>

  <?php if(Route::has('admin.reports.sales')): ?>
    <a href="<?php echo e(route('admin.reports.sales')); ?>" class="block px-3 py-2 rounded hover:bg-gray-100">
      Laporan Penjualan
    </a>
  <?php endif; ?>

  <a href="<?php echo e(route('admin.reports.opname_variance')); ?>" class="block px-3 py-2 rounded hover:bg-gray-100">
  Laporan Selisih Opname
  </a>

</nav><?php /**PATH /Users/chandrairawan/Documents/GitHub/kasir-cafe/N2n-cofe-resto/kasir-cafe/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>