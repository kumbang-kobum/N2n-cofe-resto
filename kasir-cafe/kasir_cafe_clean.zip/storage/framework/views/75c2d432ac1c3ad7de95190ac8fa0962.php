<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between mb-4">
  <h1 class="text-xl font-semibold text-blue-700">Produk / Menu</h1>

  <a href="<?php echo e(route('admin.products.create')); ?>"
     class="px-3 py-2 rounded bg-blue-600 text-white hover:bg-blue-700 text-sm">
    + Tambah Produk
  </a>
</div>

<?php if(session('status')): ?>
  <div class="mb-4 px-4 py-2 rounded bg-green-100 text-green-800 text-sm">
    <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>

<div class="bg-white border rounded-lg overflow-hidden">
  <table class="w-full text-sm">
    <thead class="bg-blue-50">
      <tr>
        <th class="p-2 text-left">Gambar</th>
        <th class="p-2 text-left">Nama</th>
        <th class="p-2 text-right">Harga Default</th>
        <th class="p-2 text-center">Aktif</th>
        <th class="p-2 text-right">Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="border-t">
          <td class="p-2">
            <?php if($product->image_path): ?>
              <img src="<?php echo e(asset('storage/'.$product->image_path)); ?>"
                   alt="<?php echo e($product->name); ?>"
                   class="w-12 h-12 rounded object-cover">
            <?php else: ?>
              <div class="w-12 h-12 rounded bg-blue-100 flex items-center justify-center text-xs text-blue-600">
                No Img
              </div>
            <?php endif; ?>
          </td>
          <td class="p-2"><?php echo e($product->name); ?></td>
          <td class="p-2 text-right">Rp <?php echo e(number_format($product->price_default,0,',','.')); ?></td>
          <td class="p-2 text-center">
            <?php if($product->is_active): ?>
              <span class="inline-flex px-2 py-1 rounded-full text-xs bg-green-100 text-green-700">Aktif</span>
            <?php else: ?>
              <span class="inline-flex px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-600">Nonaktif</span>
            <?php endif; ?>
          </td>
          <td class="p-2 text-right">
            <a href="<?php echo e(route('admin.products.edit', $product)); ?>"
               class="text-xs px-2 py-1 rounded bg-blue-500 text-white hover:bg-blue-600">
              Edit
            </a>

            <form action="<?php echo e(route('admin.products.destroy', $product)); ?>"
                  method="POST"
                  class="inline-block"
                  onsubmit="return confirm('Hapus produk ini?')">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit"
                      class="text-xs px-2 py-1 rounded bg-red-500 text-white hover:bg-red-600">
                Hapus
              </button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="5" class="p-4 text-center text-gray-500">
            Belum ada produk. Tambahkan produk pertama Anda.
          </td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<div class="mt-4">
  <?php echo e($products->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/chandrairawan/Documents/GitHub/kasir-cafe/N2n-cofe-resto/kasir-cafe/resources/views/admin/products/index.blade.php ENDPATH**/ ?>