<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between mb-4">
  <h1 class="text-xl font-semibold">Satuan</h1>

  <a href="<?php echo e(route('admin.units.create')); ?>"
     class="px-3 py-2 rounded bg-blue-600 text-white text-sm">
    + Satuan Baru
  </a>
</div>

<?php if(session('status')): ?>
  <div class="mb-4 text-sm text-green-700 bg-green-50 border border-green-200 rounded px-3 py-2">
    <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>

<div class="bg-white border rounded-lg overflow-hidden">
  <table class="w-full text-sm">
    <thead class="bg-gray-50">
      <tr>
        <th class="px-3 py-2 text-left w-16">No</th>
        <th class="px-3 py-2 text-left">Nama</th>
        <th class="px-3 py-2 text-left">Simbol</th>
        <th class="px-3 py-2 text-right w-32">Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="border-t">
          <td class="px-3 py-2"><?php echo e($loop->iteration); ?></td>
          <td class="px-3 py-2"><?php echo e($unit->name); ?></td>
          <td class="px-3 py-2"><?php echo e($unit->symbol); ?></td>
          <td class="px-3 py-2 text-right space-x-1">
            <a href="<?php echo e(route('admin.units.edit', $unit)); ?>"
               class="text-blue-600 hover:underline text-xs">
              Edit
            </a>

            <form action="<?php echo e(route('admin.units.destroy', $unit)); ?>"
                  method="POST"
                  class="inline"
                  onsubmit="return confirm('Hapus satuan ini?')">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit"
                      class="text-red-600 hover:underline text-xs">
                Hapus
              </button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="4" class="px-3 py-4 text-center text-gray-500">
            Belum ada data satuan.
          </td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/chandrairawan/Documents/GitHub/kasir-cafe/N2n-cofe-resto/kasir-cafe/resources/views/admin/units/index.blade.php ENDPATH**/ ?>