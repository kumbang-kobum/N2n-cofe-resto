<?php $__env->startSection('content'); ?>
<div class="flex flex-wrap items-center justify-between gap-2 mb-4">
    <h1 class="text-xl font-semibold">Kasir (POS)</h1>

    <form method="POST" action="<?php echo e(route('cashier.pos.new')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit"
            class="px-4 py-2 rounded-md bg-blue-600 text-white text-sm font-medium hover:bg-blue-700">
            + Transaksi Baru
        </button>
    </form>
</div>

<?php if(session('status')): ?>
    <div class="mb-4 rounded-md bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-700">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>

<?php if(!$sale): ?>
    
    <div class="bg-white border rounded-lg p-6 text-gray-700">
        Belum ada transaksi. Klik
        <span class="font-semibold">+ Transaksi Baru</span>
        untuk mulai.
    </div>
<?php else: ?>
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">

        
        <div class="bg-white border rounded-lg p-4">
            <div class="flex flex-wrap items-center justify-between gap-2 mb-4">
                <div>
                    <div class="font-semibold">Katalog Menu</div>
                    <div class="text-xs text-gray-500">
                        Klik kartu menu untuk menambah ke keranjang.
                    </div>
                </div>

                <div class="w-full sm:w-56">
                    <input type="text"
                        id="product-search"
                        placeholder="Cari menu..."
                        class="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500">
                </div>
            </div>

            <?php if($products->isEmpty()): ?>
                <div class="text-sm text-gray-500">
                    Menu tidak ditemukan.
                </div>
            <?php else: ?>
                <div id="product-grid" class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form method="POST"
                              action="<?php echo e(route('cashier.pos.add')); ?>"
                              class="product-card group bg-gray-50 rounded-lg border hover:border-blue-400 hover:bg-blue-50/40 transition cursor-pointer flex flex-col"
                              data-name="<?php echo e(Str::lower($p->name)); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="sale_id" value="<?php echo e($sale->id); ?>">
                            <input type="hidden" name="product_id" value="<?php echo e($p->id); ?>">

                            
                            <div class="w-full h-24 rounded-t-lg overflow-hidden bg-gray-100 flex items-center justify-center">
                                <?php if($p->image_path): ?>
                                    <img src="<?php echo e(asset('storage/' . $p->image_path)); ?>"
                                         alt="<?php echo e($p->name); ?>"
                                         class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-150">
                                <?php else: ?>
                                    <span class="text-[11px] text-gray-500">
                                        Tidak ada gambar
                                    </span>
                                <?php endif; ?>
                            </div>

                            
                            <div class="flex-1 flex flex-col p-2.5">
                                <div class="text-sm font-semibold leading-tight line-clamp-2">
                                    <?php echo e($p->name); ?>

                                </div>
                                <div class="text-xs text-gray-500">
                                    Rp <?php echo e(number_format($p->price_default, 0, ',', '.')); ?>

                                </div>

                                <div class="mt-2 flex items-center justify-between gap-1">
                                    <label class="text-[11px] text-gray-500">
                                        Qty
                                    </label>
                                    <input type="number"
                                           name="qty"
                                           value="1"
                                           min="1"
                                           step="1"
                                           class="w-16 rounded border border-gray-300 px-1.5 py-1 text-xs text-right focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500">
                                </div>

                                <button type="submit"
                                        class="mt-2 w-full text-[11px] font-medium text-blue-600 group-hover:text-blue-700">
                                    Tambah ke keranjang
                                </button>
                            </div>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="bg-white border rounded-lg p-4">
            <div class="flex items-center justify-between mb-3">
                <div class="font-semibold">Keranjang</div>
                <div class="text-xs text-gray-500">
                    Transaksi #<?php echo e($sale->id); ?>

                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-xs md:text-sm">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="text-left p-2">Menu</th>
                            <th class="text-right p-2">Qty</th>
                            <th class="text-right p-2">Harga</th>
                            <th class="text-right p-2">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $sale->lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="border-t">
                                <td class="p-2"><?php echo e($l->product->name); ?></td>
                                <td class="p-2 text-right"><?php echo e($l->qty); ?></td>
                                <td class="p-2 text-right">
                                    <?php echo e(number_format($l->price, 0, ',', '.')); ?>

                                </td>
                                <td class="p-2 text-right">
                                    <?php echo e(number_format($l->qty * $l->price, 0, ',', '.')); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="p-3 text-center text-xs text-gray-500">
                                    Belum ada item di keranjang.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-4 flex items-center justify-between">
                <div class="text-sm text-gray-600">Total</div>
                <div class="text-lg font-semibold">
                    Rp <?php echo e(number_format($sale->total, 0, ',', '.')); ?>

                </div>
            </div>

            <form method="POST" action="<?php echo e(route('cashier.pos.pay')); ?>" class="mt-4 space-y-2">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="sale_id" value="<?php echo e($sale->id); ?>">

                <select name="payment_method"
                        class="w-full rounded border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500">
                    <option value="CASH">CASH</option>
                    <option value="QRIS">QRIS</option>
                    <option value="DEBIT">DEBIT</option>
                </select>

                <button type="submit"
                        class="w-full px-3 py-2 rounded-md bg-green-600 hover:bg-green-700 text-white text-sm font-semibold">
                    Bayar
                </button>
            </form>
        </div>
    </div>
<?php endif; ?>


<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const searchInput = document.getElementById('product-search');
        const cards      = document.querySelectorAll('.product-card');

        if (!searchInput) return;

        searchInput.addEventListener('input', function () {
            const q = this.value.toLowerCase();

            cards.forEach(card => {
                const name = card.dataset.name || '';
                card.style.display = name.includes(q) ? '' : 'none';
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/chandrairawan/Documents/GitHub/kasir-cafe/N2n-cofe-resto/kasir-cafe/resources/views/cashier/pos.blade.php ENDPATH**/ ?>