<?php $__env->startSection('content'); ?>
<h1 class="mb-4 text-xl font-semibold">Tambah Bahan</h1>

<?php if($errors->any()): ?>
  <div class="mb-4 rounded border border-red-200 bg-red-50 px-4 py-2 text-sm text-red-800">
    <div class="font-semibold">Gagal menyimpan. Periksa kembali input:</div>
    <ul class="ml-5 list-disc">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('admin.items.store')); ?>" class="space-y-4 max-w-xl">
  <?php echo csrf_field(); ?>

  <div>
    <label class="mb-1 block text-sm font-medium text-gray-700">Nama Bahan</label>
    <input type="text" name="name" value="<?php echo e(old('name')); ?>"
           class="w-full rounded border px-3 py-2 text-sm"
           required>
  </div>

  <div>
    <label class="mb-1 block text-sm font-medium text-gray-700">Satuan Dasar</label>
    <select name="base_unit_id" class="w-full rounded border px-3 py-2 text-sm" required>
      <option value="">-- Pilih satuan --</option>
      <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($u->id); ?>" <?php if(old('base_unit_id') == $u->id): echo 'selected'; endif; ?>>
          <?php echo e($u->name); ?> (<?php echo e($u->symbol); ?>)
        </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>

  <div>
    <label class="mb-1 block text-sm font-medium text-gray-700">Min Stok (base)</label>
    <input type="number" step="0.001" name="min_stock" value="<?php echo e(old('min_stock', 0)); ?>"
           class="w-full rounded border px-3 py-2 text-sm">
  </div>

  <div class="flex items-center gap-4">
    <label class="inline-flex items-center gap-2 text-sm text-gray-700">
      <input type="checkbox" name="track_expiry" value="1"
             <?php if(old('track_expiry', true)): echo 'checked'; endif; ?>>
      Track tanggal kedaluwarsa
    </label>

    <label class="inline-flex items-center gap-2 text-sm text-gray-700">
      <input type="checkbox" name="is_active" value="1"
             <?php if(old('is_active', true)): echo 'checked'; endif; ?>>
      Aktif
    </label>
  </div>

  <div class="flex items-center gap-2">
    <a href="<?php echo e(route('admin.items.index')); ?>"
       class="rounded border px-3 py-2 text-sm text-gray-700">Batal</a>
    <button type="submit"
            class="rounded bg-blue-600 px-3 py-2 text-sm font-medium text-white hover:bg-blue-700">
      Simpan
    </button>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/chandrairawan/Documents/GitHub/kasir-cafe/N2n-cofe-resto/kasir-cafe/resources/views/admin/items/create.blade.php ENDPATH**/ ?>