<?php $__env->startSection('content'); ?>
<div class="flex items-start justify-between gap-3 mb-4">
  <div>
    <h1 class="text-xl font-semibold">Edit Resep</h1>
    <div class="text-sm text-gray-600"><?php echo e($product->name); ?></div>
  </div>
  <a class="px-3 py-1.5 rounded border bg-white" href="<?php echo e(route('admin.recipes.index')); ?>">Kembali</a>
</div>

<form method="POST" action="<?php echo e(route('admin.recipes.update', $product->id)); ?>" class="space-y-4">
  <?php echo csrf_field(); ?>

  <div class="bg-white border rounded-lg p-4 space-y-3">
    <div class="text-sm text-gray-700">Tambah bahan (boleh banyak baris).</div>

    <div class="space-y-2" id="lines">
      <?php $i=0; ?>
      <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="grid grid-cols-12 gap-2">
          <div class="col-span-12 md:col-span-5">
            <select name="lines[<?php echo e($i); ?>][item_id]" class="w-full rounded border p-2">
              <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($it->id); ?>" <?php if($it->id === $line->item_id): echo 'selected'; endif; ?>><?php echo e($it->name); ?> (base: <?php echo e($it->baseUnit->symbol); ?>)</option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="col-span-6 md:col-span-3">
            <input name="lines[<?php echo e($i); ?>][qty]" value="<?php echo e($line->qty); ?>" type="number" step="0.0001" class="w-full rounded border p-2" placeholder="Qty">
          </div>
          <div class="col-span-6 md:col-span-3">
            <select name="lines[<?php echo e($i); ?>][unit_id]" class="w-full rounded border p-2">
              <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($u->id); ?>" <?php if($u->id === $line->unit_id): echo 'selected'; endif; ?>><?php echo e($u->symbol); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="col-span-12 md:col-span-1 flex items-center">
            <button type="button" onclick="this.closest('.grid').remove()" class="w-full rounded border p-2">✕</button>
          </div>
        </div>
        <?php $i++; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <button type="button" id="addLine" class="px-3 py-2 rounded border bg-white">+ Tambah baris</button>
  </div>

  <button class="px-4 py-2 rounded bg-gray-900 text-white">Simpan Resep</button>
</form>

<script>
  const items = <?php echo json_encode($items->map(fn($it)=>['id'=>$it->id, 'name'=>$it->name, 'base'=>$it->baseUnit->symbol])) ?>;
  const units = <?php echo json_encode($units->map(fn($u)=>['id'=>$u->id, 'symbol'=>$u->symbol]), 512) ?>;
  let idx = <?php echo e($i ?? 0); ?>;

  document.getElementById('addLine').addEventListener('click', () => {
    const el = document.createElement('div');
    el.className = 'grid grid-cols-12 gap-2';
    el.innerHTML = `
      <div class="col-span-12 md:col-span-5">
        <select name="lines[${idx}][item_id]" class="w-full rounded border p-2">
          ${items.map(it => `<option value="${it.id}">${it.name} (base: ${it.base})</option>`).join('')}
        </select>
      </div>
      <div class="col-span-6 md:col-span-3">
        <input name="lines[${idx}][qty]" type="number" step="0.0001" class="w-full rounded border p-2" placeholder="Qty">
      </div>
      <div class="col-span-6 md:col-span-3">
        <select name="lines[${idx}][unit_id]" class="w-full rounded border p-2">
          ${units.map(u => `<option value="${u.id}">${u.symbol}</option>`).join('')}
        </select>
      </div>
      <div class="col-span-12 md:col-span-1 flex items-center">
        <button type="button" onclick="this.closest('.grid').remove()" class="w-full rounded border p-2">✕</button>
      </div>
    `;
    document.getElementById('lines').appendChild(el);
    idx++;
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/chandrairawan/Documents/GitHub/kasir-cafe/N2n-cofe-resto/kasir-cafe/resources/views/admin/recipes/edit.blade.php ENDPATH**/ ?>