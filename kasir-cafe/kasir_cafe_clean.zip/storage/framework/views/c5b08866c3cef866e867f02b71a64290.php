<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between mb-4">
    <div>
        <h1 class="text-xl font-semibold">Stock Opname</h1>
        <p class="text-sm text-gray-600">Daftar dokumen stock opname.</p>
    </div>

    <a href="<?php echo e(route('admin.stock_opname.create')); ?>"
       class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded">
        + Buat Opname
    </a>
</div>

<?php if(session('status')): ?>
    <div class="mb-4 p-3 bg-green-50 border border-green-200 rounded text-sm">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>

<div class="bg-white border rounded-lg overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-3 py-2 text-left">Tanggal</th>
                    <th class="px-3 py-2 text-left">Kode</th>
                    <th class="px-3 py-2 text-left">Status</th>
                    <th class="px-3 py-2 text-right"># Line</th>
                    <th class="px-3 py-2 text-left">Catatan</th>
                    <th class="px-3 py-2 text-left">Dibuat</th>
                    <th class="px-3 py-2 text-left">Posted</th>
                    <th class="px-3 py-2 text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $opnames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-t">
                        <td class="px-3 py-2 text-sm">
                            <?php echo e($opname->counted_at ? $opname->counted_at->format('d M Y') : '-'); ?>

                        </td>
                        <td class="px-3 py-2 text-sm font-mono">
                            <?php echo e($opname->code); ?>

                        </td>
                        <td class="px-3 py-2 text-xs">
                            <?php
                                $badgeClass = match($opname->status) {
                                    'DRAFT'     => 'bg-yellow-100 text-yellow-800',
                                    'POSTED'    => 'bg-green-100 text-green-800',
                                    'CANCELLED' => 'bg-red-100 text-red-800',
                                    default     => 'bg-gray-100 text-gray-800',
                                };
                            ?>
                            <span class="px-2 py-1 rounded-full <?php echo e($badgeClass); ?>">
                                <?php echo e($opname->status); ?>

                            </span>
                        </td>
                        <td class="px-3 py-2 text-right text-sm">
                            <?php echo e($opname->lines_count); ?>

                        </td>
                        <td class="px-3 py-2 text-sm truncate max-w-xs">
                            <?php echo e(\Illuminate\Support\Str::limit($opname->note, 40)); ?>

                        </td>
                        <td class="px-3 py-2 text-xs">
                            <?php echo e(optional($opname->creator)->name ?? '-'); ?><br>
                            <span class="text-gray-500">
                                <?php echo e($opname->created_at ? $opname->created_at->format('d M Y H:i') : '-'); ?>

                            </span>
                        </td>
                        <td class="px-3 py-2 text-xs">
                            <?php if($opname->posted_at): ?>
                                <?php echo e($opname->posted_at->format('d M Y H:i')); ?><br>
                                <span class="text-gray-500">
                                    <?php echo e(optional($opname->poster)->name ?? '-'); ?>

                                </span>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td class="px-3 py-2 text-right text-xs space-x-1">
                            <a href="<?php echo e(route('admin.stock_opname.show', $opname->id)); ?>"
                               class="inline-block px-2 py-1 border rounded">
                                Detail
                            </a>

                            <a href="<?php echo e(route('admin.stock_opname.pdf', $opname->id)); ?>"
                               target="_blank"
                               class="inline-block px-2 py-1 border rounded">
                                PDF
                            </a>

                            <?php if($opname->status === 'DRAFT'): ?>
                                <a href="<?php echo e(route('admin.stock_opname.edit', $opname->id)); ?>"
                                   class="inline-block px-2 py-1 border rounded">
                                    Edit
                                </a>

                                <form action="<?php echo e(route('admin.stock_opname.post', $opname->id)); ?>"
                                      method="POST"
                                      class="inline-block"
                                      onsubmit="return confirm('POST opname ini? Stok akan disesuaikan dan tidak bisa di-undo.');">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                            class="px-2 py-1 rounded bg-green-600 text-white">
                                        POST
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="px-3 py-4 text-center text-gray-500">
                            Belum ada dokumen stock opname.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-4">
    <?php echo e($opnames->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/chandrairawan/Documents/GitHub/kasir-cafe/N2n-cofe-resto/kasir-cafe/resources/views/admin/stock_opname/index.blade.php ENDPATH**/ ?>