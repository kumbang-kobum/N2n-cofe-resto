<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_','-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo e(config('app.name','Kasir Cafe')); ?></title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
</head>
<body class="bg-gray-50">
<div x-data="{ open:false }" class="min-h-screen">

  <header class="sticky top-0 z-30 bg-white border-b">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <button @click="open=!open" class="lg:hidden p-2 rounded hover:bg-gray-100">☰</button>
        <div class="font-semibold"><?php echo e(config('app.name','Kasir Cafe')); ?></div>
      </div>
      <div class="flex items-center gap-3">
        <div class="text-sm text-gray-600"><?php echo e(auth()->user()->name); ?></div>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button class="text-sm px-3 py-1.5 rounded bg-gray-900 text-white hover:bg-gray-800">Logout</button>
        </form>
      </div>
    </div>
  </header>

  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex">
      <aside class="hidden lg:block w-64 py-6">
        <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      </aside>

      <div class="lg:hidden">
        <div x-show="open" class="fixed inset-0 z-40 bg-black/40" @click="open=false"></div>
        <aside x-show="open" class="fixed z-50 top-0 left-0 w-72 h-full bg-white p-4 shadow">
          <div class="flex items-center justify-between mb-4">
            <div class="font-semibold">Menu</div>
            <button @click="open=false" class="p-2 rounded hover:bg-gray-100">✕</button>
          </div>
          <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </aside>
      </div>

      <main class="flex-1 py-6 lg:pl-8">
        <?php if(session('status')): ?>
          <div class="mb-4 p-3 rounded bg-green-50 text-green-800 border border-green-200">
            <?php echo e(session('status')); ?>

          </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
      </main>
    </div>
  </div>
</div>

<script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
</body>
</html><?php /**PATH /Users/chandrairawan/Documents/GitHub/kasir-cafe/N2n-cofe-resto/kasir-cafe/resources/views/layouts/dashboard.blade.php ENDPATH**/ ?>